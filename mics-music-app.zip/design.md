# Mics Music App - Design Plan

## Overview

**Mics** is a comprehensive music streaming and podcast platform designed for iOS/Android with a focus on seamless playback, personalized discovery, and social connectivity. The app follows Apple Human Interface Guidelines (HIG) to deliver a first-party iOS experience.

---

## Screen List

### Core Navigation (Tab Bar)

1. **Home** - Personalized feed with recommendations, trending charts, and quick access
2. **Search** - Full-text search with filters, browse genres, trending charts, new releases
3. **Library** - User's saved content: playlists, albums, artists, liked songs, recently played
4. **Now Playing** - Full-screen playback interface with album art, lyrics, queue
5. **Profile** - User account, settings, preferences, subscription management

### Secondary Screens (Modals/Navigation)

- **Now Playing Detail** - Expanded view with lyrics panel, credits, queue management
- **Queue View** - Reorderable upcoming tracks
- **Playlist Detail** - Playlist content, edit, share, collaborative options
- **Album Detail** - Album tracks, artist info, download options
- **Artist Detail** - Artist bio, top tracks, albums, followers
- **Podcast Detail** - Podcast episodes, subscribe, playback speed, chapters
- **Search Results** - Filtered results (songs, albums, artists, playlists, podcasts)
- **Downloads Manager** - Download progress, storage usage, offline content
- **Settings** - Audio quality, theme, notifications, privacy, accessibility
- **Social Feed** - Friend activity, collaborative playlists, shares
- **Device Selection** - Bluetooth/AirPlay device switching
- **Lyrics Panel** - Synced or static lyrics with scroll
- **Mini Player** - Persistent playback bar at bottom of all screens

---

## Primary Content and Functionality

### Home Screen
- **Personalized Recommendations**: AI-driven playlists (Daily Mix, Discover Weekly)
- **Trending Charts**: Global and regional top 50
- **New Releases**: This week's albums and singles
- **Recently Played**: Quick access to recently listened content
- **Featured Playlists**: Curated by Mics team
- **Genre/Mood Browse**: Chill, Workout, Focus, Party categories

### Search Screen
- **Search Bar**: Full-text search across tracks, artists, albums, playlists, podcasts, users
- **Search Filters**: Type filter (songs, albums, artists, playlists, podcasts)
- **Browse Categories**: Genre and mood-based browsing
- **Trending Now**: Current trending searches and charts
- **Recent Searches**: User's search history

### Library Screen
- **Playlists**: Create, edit, delete, reorder custom playlists
- **Liked Songs**: All saved tracks with sort options (title, artist, date added)
- **Albums**: Saved albums in grid or list layout
- **Artists**: Followed/saved artists
- **Downloaded**: Offline content with storage indicator
- **Recently Played**: Quick access to recently played items
- **Pinned Items**: Favorite playlists/podcasts at top

### Now Playing Screen
- **Album Art**: Full-size cover, sometimes animated
- **Track Info**: Title, artist (tappable), album (tappable)
- **Playback Controls**: Play/pause, skip forward/backward
- **Seek Bar**: Drag to seek, shows elapsed and total time
- **Volume Control**: In-app slider + hardware button support
- **Shuffle/Repeat**: Toggle shuffle mode and repeat options (off, repeat one, repeat all)
- **Like Button**: Save track to liked songs
- **Add to Playlist**: Quick-add without leaving screen
- **Share Button**: Share track link externally
- **Queue View**: See and reorder upcoming tracks
- **Lyrics Panel**: Synced or static lyrics scrolling with track
- **Credits/Info**: Songwriter, producer, label, release year, ISRC

### Queue View
- **Upcoming Tracks**: List of tracks to be played
- **Reorder**: Drag to reorder queue
- **Remove**: Swipe to remove from queue
- **Clear Queue**: Clear all upcoming tracks

### Playlist Detail
- **Playlist Header**: Cover, title, description, follower count
- **Playlist Tracks**: Editable list of tracks
- **Add Tracks**: Search and add new tracks
- **Collaborative Mode**: Invite friends to add tracks
- **Share Playlist**: Generate shareable link
- **Download Playlist**: Download all tracks for offline
- **Delete Playlist**: Remove playlist

### Album Detail
- **Album Header**: Cover art, title, artist, release year
- **Album Tracks**: All tracks with play, like, add to playlist options
- **Artist Info**: Tap to go to artist detail
- **Download Album**: Download all tracks
- **Share Album**: Share link

### Artist Detail
- **Artist Header**: Profile image, name, follower count, follow button
- **Top Tracks**: Artist's most popular tracks
- **Albums**: Artist's discography
- **Related Artists**: Similar artists
- **Artist Radio**: Create radio station from artist

### Podcast Detail
- **Podcast Header**: Cover, title, description, subscriber count
- **Episodes List**: All episodes with download, playback speed, chapter markers
- **Subscribe Button**: Subscribe/unsubscribe
- **Episode Detail**: Show notes, transcript, chapters

### Settings Screen
- **Audio Quality**: Low/Normal/High/Very High/Lossless/HiFi options
- **Download Quality**: Separate setting for offline downloads
- **Equalizer**: Preset and custom band adjustments
- **Loudness Normalization**: Toggle ReplayGain/LUFS
- **Mono Audio**: Accessibility option
- **Sleep Timer**: Set duration to stop playback
- **Automix/DJ Mode**: Auto-transitions with beat-matching
- **Theme**: Dark/Light/Auto (follows system)
- **Text Size**: Dynamic type scaling
- **Notifications**: New releases, recommendations, social activity
- **Privacy**: Public/private profile, data download, personalization opt-out
- **Accessibility**: Screen reader support, high contrast, haptic feedback
- **Language & Region**: App language and store region
- **Help & Support**: FAQ, live chat, bug reporting

### Profile Screen
- **User Info**: Profile picture, name, bio
- **Subscription**: Current plan, upgrade option
- **Account Settings**: Email, password, linked accounts (Google, Apple, Facebook)
- **Payment & Billing**: Update card, view invoices, cancel subscription
- **Multi-Device Sync**: Show synced devices
- **Listening Activity**: Public/private toggle
- **Logout**: Sign out option

---

## Key User Flows

### Flow 1: Play a Track
1. User navigates to Home/Search/Library
2. Taps a track or playlist
3. Track starts playing with Now Playing screen displayed
4. Mini player appears at bottom of all screens
5. User can skip, pause, seek, like, or add to playlist
6. Swipe up to see full Now Playing screen with lyrics and queue

### Flow 2: Create and Share a Playlist
1. User taps "Create Playlist" in Library
2. Enters playlist name and description
3. Searches and adds tracks
4. Taps "Share" to generate link
5. Shares via Messages, WhatsApp, Instagram, etc.
6. Optionally enables collaborative mode for friends to add tracks

### Flow 3: Download for Offline
1. User taps download icon on track/album/playlist
2. Download manager shows progress
3. Once complete, content available in Downloaded section
4. User can play offline without internet
5. Storage usage indicator shows space used

### Flow 4: Discover New Music
1. User opens Home screen
2. Browses Trending Charts, New Releases, or Genre categories
3. Taps a track or artist to explore
4. Views artist detail, related artists, top tracks
5. Adds favorites to liked songs or playlists
6. Receives personalized recommendations based on activity

### Flow 5: Control Playback from Lock Screen
1. Music playing in background
2. Lock screen shows now playing card
3. User can play, pause, skip without unlocking phone
4. Notification shade shows persistent media controls
5. Hardware volume buttons adjust playback volume

### Flow 6: Use Bluetooth/AirPlay Device
1. User opens Device Selection screen
2. Sees list of paired Bluetooth headphones/speakers
3. Taps device to switch playback
4. Music streams to selected device
5. Can also use AirPlay, Chromecast, Sonos integration

### Flow 7: Access Podcasts
1. User opens Search and finds podcast
2. Taps Subscribe button
3. Episodes appear in Library under Podcasts
4. Taps episode to play
5. Can adjust playback speed (0.5x to 3.5x)
6. Skip silence removes quiet gaps automatically
7. Chapter markers allow jumping to named sections

### Flow 8: Social Sharing
1. User taps Share button on track/playlist
2. Selects share method (Messages, WhatsApp, Instagram Stories, etc.)
3. Generates shareable link with preview
4. Friends can tap link to open in Mics app
5. Friend activity feed shows what others are listening to

---

## Color Choices

### Brand Colors (Mics Theme)
- **Primary**: `#0A7EA4` (Vibrant Teal) - Main accent, buttons, highlights
- **Secondary**: `#FF6B35` (Warm Orange) - Secondary actions, likes, highlights
- **Background Light**: `#FFFFFF` - Light mode background
- **Background Dark**: `#0F0F0F` - Dark mode background
- **Surface Light**: `#F5F5F5` - Cards, surfaces in light mode
- **Surface Dark**: `#1A1A1A` - Cards, surfaces in dark mode
- **Text Primary Light**: `#1A1A1A` - Primary text in light mode
- **Text Primary Dark**: `#FFFFFF` - Primary text in dark mode
- **Text Secondary Light**: `#666666` - Secondary text in light mode
- **Text Secondary Dark**: `#AAAAAA` - Secondary text in dark mode
- **Accent Green**: `#22C55E` - Success states, download complete
- **Accent Red**: `#EF4444` - Error states, delete actions
- **Accent Yellow**: `#F59E0B` - Warning states, notifications

### Dynamic Color Matching
- App accent color shifts to match current album art dominant color
- Lyrics panel background matches album art color
- Mini player accent matches now playing track

---

## Interaction Patterns

### Gestures
- **Swipe Down**: Dismiss full Now Playing screen
- **Swipe Left/Right**: Skip to next/previous track
- **Long Press**: Open context menu (add to playlist, share, delete)
- **Double Tap**: Like/unlike track
- **Drag**: Reorder queue, seek in track, adjust volume

### Haptic Feedback
- **Light Impact**: Like button, skip action, queue reorder
- **Medium Impact**: Toggle shuffle/repeat, playlist creation
- **Success Notification**: Download complete, playlist saved
- **Error Notification**: Download failed, network error

### Animations
- **Fade In**: Album art transitions, screen changes
- **Slide Up**: Mini player expansion to full screen
- **Crossfade**: Track transitions with gapless playback
- **Pulse**: Like button animation when tapped
- **Rotate**: Loading spinner during downloads

---

## Accessibility Features

- **Screen Reader Support**: All buttons and images labeled for VoiceOver/TalkBack
- **High Contrast Mode**: Increased border and text contrast
- **Dynamic Type**: Text scales with system accessibility font size
- **Mono Audio**: Combines L/R channels for hearing accessibility
- **Haptic Feedback**: Subtle vibration on actions
- **Explicit Content Filter**: Toggle to hide marked tracks

---

## Mini Player Design

- **Position**: Persistent bar at bottom of every screen while music plays
- **Content**: Album art thumbnail, track title, artist, play/pause button, skip button
- **Interaction**: Tap to expand to full Now Playing screen
- **Swipe**: Swipe up to expand, swipe down to minimize
- **Visibility**: Always visible above tab bar, never hidden

---

## Theme Support

- **Dark Mode**: Follows system setting or manual toggle
- **Light Mode**: Bright, clean interface for daytime use
- **Auto Mode**: Switches based on time of day and system setting
- **Color-Matched UI**: Accent color shifts based on album art

---

## Performance Considerations

- **Lazy Loading**: Load content as user scrolls
- **Image Caching**: Cache album art and profile images
- **Audio Buffering**: Pre-buffer next track for gapless playback
- **Pagination**: Load search results and playlists in batches
- **Offline Support**: Cache downloaded tracks for offline playback

---

## Notes

This design prioritizes **one-handed usage** with thumb-accessible controls at the bottom of the screen. All primary actions (play, skip, like) are within thumb reach. Secondary actions are accessed via swipe gestures or long-press menus. The app maintains consistency with iOS HIG standards while providing a unique visual identity through color matching and dynamic theming.
