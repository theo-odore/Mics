# Mics Music App - Project TODO

## Phase 1: Core Infrastructure & Branding
- [x] Generate custom app logo/icon
- [x] Update app.config.ts with branding (appName, logoUrl)
- [x] Set up color theme in theme.config.js
- [x] Configure tab bar with all navigation screens
- [x] Set up theme provider and dark/light mode toggle

## Phase 2: Core UI Screens
- [x] Home screen with personalized recommendations
- [x] Search screen with full-text search and filters
- [x] Library screen with playlists, albums, artists, liked songs
- [x] Now Playing screen (basic playback controls)
- [x] Profile/Settings screen
- [ ] Mini player component (persistent at bottom)

## Phase 3: Core Playback Features
- [ ] Audio player setup (expo-audio)
- [ ] Play/pause functionality
- [ ] Skip forward/backward
- [ ] Seek bar with drag-to-seek
- [ ] Volume control (in-app slider + hardware buttons)
- [ ] Shuffle mode toggle
- [ ] Repeat modes (off, repeat one, repeat all)
- [ ] Gapless playback
- [ ] Crossfade between tracks

## Phase 4: Library & Organization
- [ ] Create/edit/delete playlists
- [ ] Add/remove tracks from playlists
- [ ] Reorder playlist tracks
- [ ] Albums view (grid/list layouts)
- [ ] Artists view (followed artists)
- [ ] Liked songs list (sortable)
- [ ] Recently played tracking
- [ ] Pinned items (playlists/podcasts)
- [ ] Local file import (MP3/FLAC/AAC)

## Phase 5: Search & Discovery
- [ ] Full-text search implementation
- [ ] Search filters (songs, albums, artists, playlists, podcasts)
- [ ] Genre & mood browsing
- [ ] Trending charts (global and per-country)
- [ ] New releases section
- [ ] Personalized recommendations (Daily Mix, Discover Weekly)
- [ ] Radio/artist radio functionality
- [ ] Recommended because you liked X

## Phase 6: Audio Quality & Settings
- [ ] Streaming quality tiers (Low/Normal/High/Very High/Lossless/HiFi)
- [ ] Download quality settings
- [ ] Equalizer (preset and custom band adjustments)
- [ ] Loudness normalization (ReplayGain/LUFS)
- [ ] Mono audio option
- [ ] Automix/DJ mode
- [ ] Sleep timer

## Phase 7: Downloads & Offline
- [ ] Download tracks/albums/playlists
- [ ] Download manager with progress tracking
- [ ] Storage usage indicator
- [ ] Wi-Fi only download option
- [ ] Auto-download followed artists' new releases
- [ ] Offline playback support

## Phase 8: Now Playing Screen Details
- [ ] Full-size album art display
- [ ] Album art animation support
- [ ] Track title, artist, album (tappable links)
- [ ] Like/heart button
- [ ] Add to playlist quick-action
- [ ] Share button
- [ ] Queue view with reordering
- [ ] Lyrics panel (synced/static)
- [ ] Credits/info display (songwriter, producer, label, ISRC)

## Phase 9: Social & Sharing
- [ ] Collaborative playlists
- [ ] Friend activity feed
- [ ] Share track/playlist links
- [ ] Share to Stories (Instagram/Snapchat)
- [ ] Public/private profile toggle
- [ ] Blend/merge playlist feature
- [ ] User profiles

## Phase 10: Podcasts & Other Content
- [ ] Podcast library/subscription
- [ ] Podcast episodes browsing
- [ ] Playback speed control (0.5x to 3.5x)
- [ ] Skip silence feature
- [ ] Chapter markers navigation
- [ ] Audiobooks support
- [ ] Podcast downloads

## Phase 11: Devices & Connectivity
- [ ] Bluetooth device list and switching
- [ ] Cast/stream to device (Chromecast, AirPlay 2, Sonos)
- [ ] Remote control from another device
- [ ] Car mode/driving view
- [ ] Smart speaker integration (Google Assistant, Siri, Alexa)
- [ ] Lock screen controls
- [ ] Notification media controls
- [ ] Widget support (home screen)

## Phase 12: Account & Subscription
- [ ] Sign up/login (Email, Google, Apple, Facebook)
- [ ] Free vs premium tiers
- [ ] Family/duo/student plans
- [ ] Payment & billing settings
- [ ] Multi-device sync
- [ ] Data & privacy settings
- [ ] Notification preferences

## Phase 13: Accessibility & Polish
- [ ] Dark/light theme toggle
- [ ] Text size/dynamic type scaling
- [ ] Screen reader support (VoiceOver/TalkBack)
- [ ] High-contrast mode
- [ ] Swipe gestures (down to dismiss, left/right to skip)
- [ ] Haptic feedback
- [ ] Animated album art/canvas
- [ ] Color-matched UI (accent color from album art)
- [ ] Explicit content filter
- [ ] Language & region settings
- [ ] Help & support section

## Phase 14: Testing & Delivery
- [ ] End-to-end testing of all flows
- [ ] Performance optimization
- [ ] Bug fixes and polish
- [ ] Create final checkpoint
- [ ] Prepare for deployment
