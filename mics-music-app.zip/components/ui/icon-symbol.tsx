// Fallback for using MaterialIcons on Android and web.

import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { SymbolWeight, SymbolViewProps } from "expo-symbols";
import { ComponentProps } from "react";
import { OpaqueColorValue, type StyleProp, type TextStyle } from "react-native";

type IconMapping = Record<string, ComponentProps<typeof MaterialIcons>["name"]>;
type IconSymbolName = keyof typeof MAPPING;

/**
 * Add your SF Symbols to Material Icons mappings here.
 * - see Material Icons in the [Icons Directory](https://icons.expo.fyi).
 * - see SF Symbols in the [SF Symbols](https://developer.apple.com/sf-symbols/) app.
 */
const MAPPING: IconMapping = {
  "house.fill": "home",
  "paperplane.fill": "send",
  "chevron.left.forwardslash.chevron.right": "code",
  "chevron.right": "chevron-right",
  "magnifyingglass": "search",
  "music.note.list": "library-music",
  "play.circle.fill": "play-circle",
  "person.fill": "person",
  "heart.fill": "favorite",
  "heart": "favorite-border",
  "square.and.arrow.up": "share",
  "list.bullet": "list",
  "slider.horizontal.3": "tune",
  "gear": "settings",
  "xmark": "close",
  "plus": "add",
  "minus": "remove",
  "ellipsis": "more-vert",
  "shuffle": "shuffle",
  "repeat": "repeat",
  "repeat.1": "repeat-one",
  "speaker.fill": "speaker",
  "volume.2.fill": "volume-up",
  "volume.mute.fill": "volume-mute",
  "backward.fill": "skip-previous",
  "forward.fill": "skip-next",
  "pause.fill": "pause",
  "play.fill": "play-arrow",
  "square.fill": "stop",
  "download": "download",
  "cloud.download.fill": "cloud-download",
  "wifi": "wifi",
  "bluetooth": "bluetooth-audio",
  "airplay": "airplay",
  "clock": "schedule",
  "mic.fill": "mic",
  "waveform.circle.fill": "graphic-eq",
};

/**
 * An icon component that uses native SF Symbols on iOS, and Material Icons on Android and web.
 * This ensures a consistent look across platforms, and optimal resource usage.
 * Icon `name`s are based on SF Symbols and require manual mapping to Material Icons.
 */
export function IconSymbol({
  name,
  size = 24,
  color,
  style,
}: {
  name: IconSymbolName;
  size?: number;
  color: string | OpaqueColorValue;
  style?: StyleProp<TextStyle>;
  weight?: SymbolWeight;
}) {
  return <MaterialIcons color={color} size={size} name={MAPPING[name as string]} style={style} />;
}
