import { ScrollView, Text, View, TouchableOpacity, TextInput, FlatList } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { useState } from "react";
import { IconSymbol } from "@/components/ui/icon-symbol";

interface SearchResult {
  id: string;
  title: string;
  subtitle: string;
  type: "track" | "artist" | "album" | "playlist";
}

export default function SearchScreen() {
  const colors = useColors();
  const [searchQuery, setSearchQuery] = useState("");
  const [activeFilter, setActiveFilter] = useState<string | null>(null);

  const filters = ["All", "Tracks", "Artists", "Albums", "Playlists", "Podcasts"];

  const searchResults: SearchResult[] = [
    { id: "1", title: "Blinding Lights", subtitle: "The Weeknd", type: "track" },
    { id: "2", title: "The Weeknd", subtitle: "Artist", type: "artist" },
    { id: "3", title: "After Hours", subtitle: "Album", type: "album" },
    { id: "4", title: "Weekend Vibes", subtitle: "Playlist", type: "playlist" },
  ];

  const genres = [
    { id: "1", name: "Chill", color: colors.primary },
    { id: "2", name: "Workout", color: "#FF6B35" },
    { id: "3", name: "Focus", color: colors.success },
    { id: "4", name: "Party", color: colors.warning },
    { id: "5", name: "Sad", color: colors.error },
    { id: "6", name: "Sleep", color: colors.primary },
  ];

  const renderSearchResult = ({ item }: { item: SearchResult }) => (
    <TouchableOpacity className="flex-row items-center py-3 px-4 border-b border-border">
      <View
        className="w-12 h-12 rounded-lg mr-3 justify-center items-center"
        style={{ backgroundColor: colors.surface }}
      >
        <IconSymbol
          name={
            item.type === "track"
              ? "play.fill"
              : item.type === "artist"
                ? "person.fill"
                : item.type === "album"
                  ? "music.note.list"
                  : "list.bullet"
          }
          size={20}
          color={colors.primary}
        />
      </View>
      <View className="flex-1">
        <Text className="text-foreground font-semibold">{item.title}</Text>
        <Text className="text-xs text-muted mt-1">{item.subtitle}</Text>
      </View>
      <TouchableOpacity>
        <IconSymbol name="play.fill" size={24} color={colors.primary} />
      </TouchableOpacity>
    </TouchableOpacity>
  );

  const renderGenreCard = ({ item }: { item: { id: string; name: string; color: string } }) => (
    <TouchableOpacity className="mr-3 mb-3">
      <View
        className="px-4 py-3 rounded-full"
        style={{ backgroundColor: item.color }}
      >
        <Text className="text-white font-semibold text-sm">{item.name}</Text>
      </View>
    </TouchableOpacity>
  );

  return (
    <ScreenContainer className="bg-background">
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View className="px-6 pt-6 pb-4">
          <Text className="text-3xl font-bold text-foreground">Search</Text>
        </View>

        {/* Search Bar */}
        <View className="px-6 pb-4">
          <View
            className="flex-row items-center px-4 py-3 rounded-full"
            style={{ backgroundColor: colors.surface }}
          >
            <IconSymbol name="magnifyingglass" size={20} color={colors.muted} />
            <TextInput
              placeholder="Search songs, artists, albums..."
              placeholderTextColor={colors.muted}
              value={searchQuery}
              onChangeText={setSearchQuery}
              className="flex-1 ml-3 text-foreground"
            />
          </View>
        </View>

        {searchQuery ? (
          <>
            {/* Filter Tabs */}
            <View className="px-6 pb-4 flex-row gap-2">
              {filters.map((filter) => (
                <TouchableOpacity
                  key={filter}
                  onPress={() => setActiveFilter(filter)}
                  className="px-3 py-2 rounded-full"
                  style={{
                    backgroundColor:
                      activeFilter === filter ? colors.primary : colors.surface,
                  }}
                >
                  <Text
                    className="text-sm font-semibold"
                    style={{
                      color:
                        activeFilter === filter ? "#FFFFFF" : colors.foreground,
                    }}
                  >
                    {filter}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>

            {/* Search Results */}
            <FlatList
              data={searchResults}
              renderItem={renderSearchResult}
              keyExtractor={(item) => item.id}
              scrollEnabled={false}
            />
          </>
        ) : (
          <>
            {/* Browse Categories */}
            <View className="px-6 pb-4">
              <Text className="text-xl font-bold text-foreground mb-4">
                Browse All
              </Text>
              <FlatList
                data={genres}
                renderItem={renderGenreCard}
                keyExtractor={(item) => item.id}
                numColumns={2}
                scrollEnabled={false}
                columnWrapperStyle={{ justifyContent: "space-between" }}
              />
            </View>

            {/* Trending Section */}
            <View className="px-6 py-4">
              <Text className="text-xl font-bold text-foreground mb-4">
                Trending Now
              </Text>
              <FlatList
                data={searchResults.slice(0, 3)}
                renderItem={renderSearchResult}
                keyExtractor={(item) => item.id}
                scrollEnabled={false}
              />
            </View>
          </>
        )}

        {/* Spacer */}
        <View className="h-8" />
      </ScrollView>
    </ScreenContainer>
  );
}
