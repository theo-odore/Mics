import { ScrollView, Text, View, TouchableOpacity } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { useState } from "react";

interface ProfileMenuItem {
  id: string;
  label: string;
  icon: string;
  action: () => void;
}

export default function ProfileScreen() {
  const colors = useColors();
  const [isDarkMode, setIsDarkMode] = useState(false);

  const menuItems: ProfileMenuItem[] = [
    {
      id: "1",
      label: "Account Settings",
      icon: "gear",
      action: () => console.log("Account Settings"),
    },
    {
      id: "2",
      label: "Audio Quality",
      icon: "waveform.circle.fill",
      action: () => console.log("Audio Quality"),
    },
    {
      id: "3",
      label: "Downloads",
      icon: "cloud.download.fill",
      action: () => console.log("Downloads"),
    },
    {
      id: "4",
      label: "Notifications",
      icon: "bell",
      action: () => console.log("Notifications"),
    },
    {
      id: "5",
      label: "Privacy & Data",
      icon: "lock",
      action: () => console.log("Privacy"),
    },
    {
      id: "6",
      label: "Help & Support",
      icon: "questionmark.circle",
      action: () => console.log("Help"),
    },
  ];

  const renderMenuItem = (item: ProfileMenuItem) => (
    <TouchableOpacity
      key={item.id}
      onPress={item.action}
      className="flex-row items-center py-4 px-6 border-b border-border"
    >
      <IconSymbol name={item.icon as any} size={24} color={colors.primary} />
      <Text className="text-foreground font-semibold ml-4 flex-1">
        {item.label}
      </Text>
      <IconSymbol name="chevron.right" size={20} color={colors.muted} />
    </TouchableOpacity>
  );

  return (
    <ScreenContainer className="bg-background">
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Profile Header */}
        <View className="px-6 pt-6 pb-8 items-center">
          <View
            className="w-24 h-24 rounded-full justify-center items-center mb-4"
            style={{ backgroundColor: colors.primary }}
          >
            <IconSymbol name="person.fill" size={48} color="#FFFFFF" />
          </View>
          <Text className="text-2xl font-bold text-foreground">Music Lover</Text>
          <Text className="text-muted mt-1">Premium Member</Text>
        </View>

        {/* Subscription Card */}
        <View className="px-6 pb-8">
          <View
            className="p-4 rounded-lg"
            style={{ backgroundColor: colors.primary }}
          >
            <Text className="text-white font-bold mb-2">Premium Subscription</Text>
            <Text className="text-white text-sm mb-3">
              Enjoy unlimited skips, offline downloads, and ad-free listening
            </Text>
            <TouchableOpacity className="bg-white px-4 py-2 rounded-lg self-start">
              <Text className="text-primary font-semibold">Manage</Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* Theme Toggle */}
        <View className="px-6 pb-6">
          <View className="flex-row items-center justify-between py-4 px-4 bg-surface rounded-lg">
            <View className="flex-row items-center">
              <IconSymbol name="moon.fill" size={24} color={colors.primary} />
              <Text className="text-foreground font-semibold ml-3">Dark Mode</Text>
            </View>
            <TouchableOpacity
              onPress={() => setIsDarkMode(!isDarkMode)}
              className="px-4 py-2 rounded-full"
              style={{
                backgroundColor: isDarkMode ? colors.primary : colors.border,
              }}
            >
              <Text
                className="font-semibold"
                style={{
                  color: isDarkMode ? "#FFFFFF" : colors.foreground,
                }}
              >
                {isDarkMode ? "On" : "Off"}
              </Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* Menu Items */}
        <View className="pb-6">
          {menuItems.map(renderMenuItem)}
        </View>

        {/* Logout Button */}
        <View className="px-6 pb-8">
          <TouchableOpacity
            className="py-4 px-6 rounded-lg border-2"
            style={{ borderColor: colors.error }}
          >
            <Text className="text-center font-semibold" style={{ color: colors.error }}>
              Sign Out
            </Text>
          </TouchableOpacity>
        </View>

        {/* App Version */}
        <View className="px-6 pb-8 items-center">
          <Text className="text-muted text-xs">Mics v1.0.0</Text>
        </View>

        {/* Spacer */}
        <View className="h-8" />
      </ScrollView>
    </ScreenContainer>
  );
}
