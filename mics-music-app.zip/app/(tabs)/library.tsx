import { ScrollView, Text, View, TouchableOpacity, FlatList } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { useState } from "react";

interface LibraryItem {
  id: string;
  title: string;
  subtitle: string;
  type: "playlist" | "album" | "artist" | "liked";
  count?: number;
}

export default function LibraryScreen() {
  const colors = useColors();
  const [activeTab, setActiveTab] = useState<"all" | "playlists" | "albums" | "artists">("all");

  const libraryItems: LibraryItem[] = [
    { id: "1", title: "Liked Songs", subtitle: "45 songs", type: "liked", count: 45 },
    { id: "2", title: "Workout Mix", subtitle: "32 songs", type: "playlist", count: 32 },
    { id: "3", title: "Chill Vibes", subtitle: "28 songs", type: "playlist", count: 28 },
    { id: "4", title: "After Hours", subtitle: "The Weeknd", type: "album" },
    { id: "5", title: "Blinding Lights", subtitle: "The Weeknd", type: "album" },
    { id: "6", title: "The Weeknd", subtitle: "Artist", type: "artist" },
    { id: "7", title: "Taylor Swift", subtitle: "Artist", type: "artist" },
  ];

  const tabs = [
    { id: "all", label: "All" },
    { id: "playlists", label: "Playlists" },
    { id: "albums", label: "Albums" },
    { id: "artists", label: "Artists" },
  ];

  const filteredItems = libraryItems.filter((item) => {
    if (activeTab === "all") return true;
    if (activeTab === "playlists") return item.type === "playlist" || item.type === "liked";
    if (activeTab === "albums") return item.type === "album";
    if (activeTab === "artists") return item.type === "artist";
    return true;
  });

  const renderLibraryItem = ({ item }: { item: LibraryItem }) => (
    <TouchableOpacity className="flex-row items-center py-3 px-4 border-b border-border">
      <View
        className="w-14 h-14 rounded-lg mr-4 justify-center items-center"
        style={{ backgroundColor: colors.surface }}
      >
        <IconSymbol
          name={
            item.type === "liked"
              ? "heart.fill"
              : item.type === "playlist"
                ? "list.bullet"
                : item.type === "album"
                  ? "music.note.list"
                  : "person.fill"
          }
          size={24}
          color={item.type === "liked" ? colors.error : colors.primary}
        />
      </View>
      <View className="flex-1">
        <Text className="text-foreground font-semibold">{item.title}</Text>
        <Text className="text-xs text-muted mt-1">{item.subtitle}</Text>
      </View>
      <TouchableOpacity>
        <IconSymbol name="ellipsis" size={20} color={colors.muted} />
      </TouchableOpacity>
    </TouchableOpacity>
  );

  return (
    <ScreenContainer className="bg-background">
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View className="px-6 pt-6 pb-4">
          <Text className="text-3xl font-bold text-foreground">Library</Text>
        </View>

        {/* Tab Navigation */}
        <View className="px-6 pb-4 flex-row gap-2">
          {tabs.map((tab) => (
            <TouchableOpacity
              key={tab.id}
              onPress={() => setActiveTab(tab.id as any)}
              className="px-4 py-2 rounded-full"
              style={{
                backgroundColor: activeTab === tab.id ? colors.primary : colors.surface,
              }}
            >
              <Text
                className="text-sm font-semibold"
                style={{
                  color: activeTab === tab.id ? "#FFFFFF" : colors.foreground,
                }}
              >
                {tab.label}
              </Text>
            </TouchableOpacity>
          ))}
        </View>

        {/* Create Playlist Button */}
        <View className="px-6 pb-4">
          <TouchableOpacity
            className="flex-row items-center py-3 px-4 rounded-lg"
            style={{ backgroundColor: colors.primary }}
          >
            <IconSymbol name="plus" size={20} color="#FFFFFF" />
            <Text className="text-white font-semibold ml-2">Create Playlist</Text>
          </TouchableOpacity>
        </View>

        {/* Library Items */}
        {filteredItems.length > 0 ? (
          <FlatList
            data={filteredItems}
            renderItem={renderLibraryItem}
            keyExtractor={(item) => item.id}
            scrollEnabled={false}
          />
        ) : (
          <View className="px-6 py-12 items-center">
            <IconSymbol name="music.note.list" size={48} color={colors.muted} />
            <Text className="text-foreground font-semibold mt-4">No {activeTab} yet</Text>
            <Text className="text-muted text-sm mt-2">Start adding your favorites</Text>
          </View>
        )}

        {/* Spacer */}
        <View className="h-8" />
      </ScrollView>
    </ScreenContainer>
  );
}
