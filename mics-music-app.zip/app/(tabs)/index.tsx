import { ScrollView, Text, View, TouchableOpacity, FlatList } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";

interface RecommendedPlaylist {
  id: string;
  title: string;
  description: string;
  coverColor: string;
}

interface TrendingTrack {
  id: string;
  title: string;
  artist: string;
  rank: number;
}

export default function HomeScreen() {
  const colors = useColors();

  const recommendedPlaylists: RecommendedPlaylist[] = [
    {
      id: "1",
      title: "Daily Mix",
      description: "Your personalized daily playlist",
      coverColor: colors.primary,
    },
    {
      id: "2",
      title: "Discover Weekly",
      description: "New music tailored for you",
      coverColor: "#FF6B35",
    },
    {
      id: "3",
      title: "Chill Vibes",
      description: "Relaxing tracks to unwind",
      coverColor: colors.success,
    },
  ];

  const trendingTracks: TrendingTrack[] = [
    { id: "1", title: "Blinding Lights", artist: "The Weeknd", rank: 1 },
    { id: "2", title: "As It Was", artist: "Harry Styles", rank: 2 },
    { id: "3", title: "Anti-Hero", artist: "Taylor Swift", rank: 3 },
    { id: "4", title: "Vampire", artist: "Olivia Rodrigo", rank: 4 },
    { id: "5", title: "Flowers", artist: "Miley Cyrus", rank: 5 },
  ];

  const renderPlaylistCard = (playlist: RecommendedPlaylist) => (
    <TouchableOpacity
      key={playlist.id}
      className="mr-4 rounded-lg overflow-hidden"
      style={{ width: 160 }}
    >
      <View
        className="h-32 justify-center items-center"
        style={{ backgroundColor: playlist.coverColor }}
      >
        <Text className="text-white font-bold text-lg text-center px-2">
          {playlist.title}
        </Text>
      </View>
      <View className="bg-surface p-3">
        <Text className="text-xs text-muted">{playlist.description}</Text>
      </View>
    </TouchableOpacity>
  );

  const renderTrendingTrack = ({ item, index }: { item: TrendingTrack; index: number }) => (
    <TouchableOpacity className="flex-row items-center py-3 px-4 border-b border-border">
      <Text
        className="text-lg font-bold text-primary mr-4"
        style={{ width: 30 }}
      >
        {item.rank}
      </Text>
      <View className="flex-1">
        <Text className="text-foreground font-semibold">{item.title}</Text>
        <Text className="text-sm text-muted mt-1">{item.artist}</Text>
      </View>
      <TouchableOpacity className="ml-4">
        <Text className="text-primary font-semibold">Play</Text>
      </TouchableOpacity>
    </TouchableOpacity>
  );

  return (
    <ScreenContainer className="bg-background">
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View className="px-6 pt-6 pb-4">
          <Text className="text-3xl font-bold text-foreground">Mics</Text>
          <Text className="text-sm text-muted mt-1">Welcome back!</Text>
        </View>

        {/* Personalized Recommendations Section */}
        <View className="py-4">
          <Text className="text-xl font-bold text-foreground px-6 mb-4">
            For You
          </Text>
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={{ paddingHorizontal: 24 }}
          >
            {recommendedPlaylists.map(renderPlaylistCard)}
          </ScrollView>
        </View>

        {/* Trending Charts Section */}
        <View className="py-6">
          <View className="px-6 mb-4 flex-row justify-between items-center">
            <Text className="text-xl font-bold text-foreground">
              Trending Now
            </Text>
            <TouchableOpacity>
              <Text className="text-primary font-semibold">See All</Text>
            </TouchableOpacity>
          </View>
          <FlatList
            data={trendingTracks}
            renderItem={renderTrendingTrack}
            keyExtractor={(item) => item.id}
            scrollEnabled={false}
          />
        </View>

        {/* New Releases Section */}
        <View className="py-6 px-6">
          <View className="flex-row justify-between items-center mb-4">
            <Text className="text-xl font-bold text-foreground">
              New Releases
            </Text>
            <TouchableOpacity>
              <Text className="text-primary font-semibold">See All</Text>
            </TouchableOpacity>
          </View>
          <View className="flex-row gap-4">
            {[1, 2, 3].map((i) => (
              <TouchableOpacity key={i} className="flex-1">
                <View
                  className="h-32 rounded-lg bg-surface justify-center items-center"
                >
                  <Text className="text-foreground font-semibold">
                    Album {i}
                  </Text>
                </View>
                <Text className="text-sm text-foreground font-semibold mt-2">
                  Artist Name
                </Text>
                <Text className="text-xs text-muted">Album Title</Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* Spacer for tab bar */}
        <View className="h-8" />
      </ScrollView>
    </ScreenContainer>
  );
}
