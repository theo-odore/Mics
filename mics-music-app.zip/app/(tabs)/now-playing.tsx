import { ScrollView, Text, View, TouchableOpacity, Dimensions } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { useState } from "react";

const { width } = Dimensions.get("window");

export default function NowPlayingScreen() {
  const colors = useColors();
  const [isPlaying, setIsPlaying] = useState(true);
  const [isShuffle, setIsShuffle] = useState(false);
  const [repeatMode, setRepeatMode] = useState<"off" | "all" | "one">("off");
  const [isLiked, setIsLiked] = useState(false);
  const [progress, setProgress] = useState(0.45);

  const currentTrack = {
    title: "Blinding Lights",
    artist: "The Weeknd",
    album: "After Hours",
    duration: 200,
    currentTime: 90,
  };

  const handleRepeatClick = () => {
    if (repeatMode === "off") setRepeatMode("all");
    else if (repeatMode === "all") setRepeatMode("one");
    else setRepeatMode("off");
  };

  return (
    <ScreenContainer className="bg-background">
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Album Art Container */}
        <View className="px-6 pt-6 pb-8">
          <View
            className="w-full rounded-2xl justify-center items-center"
            style={{
              width: width - 48,
              height: width - 48,
              backgroundColor: colors.primary,
            }}
          >
            <Text className="text-white text-6xl font-bold">♪</Text>
          </View>
        </View>

        {/* Track Info */}
        <View className="px-6 pb-6">
          <View className="flex-row justify-between items-start mb-2">
            <View className="flex-1">
              <Text className="text-2xl font-bold text-foreground">
                {currentTrack.title}
              </Text>
              <TouchableOpacity className="mt-1">
                <Text className="text-primary font-semibold">
                  {currentTrack.artist}
                </Text>
              </TouchableOpacity>
            </View>
            <TouchableOpacity
              onPress={() => setIsLiked(!isLiked)}
              className="ml-4"
            >
              <IconSymbol
                name={isLiked ? "heart.fill" : "heart"}
                size={28}
                color={isLiked ? colors.error : colors.muted}
              />
            </TouchableOpacity>
          </View>
          <TouchableOpacity>
            <Text className="text-muted text-sm mt-1">{currentTrack.album}</Text>
          </TouchableOpacity>
        </View>

        {/* Progress Bar */}
        <View className="px-6 pb-4">
          <View
            className="h-1 rounded-full mb-3"
            style={{ backgroundColor: colors.border }}
          >
            <View
              className="h-1 rounded-full"
              style={{
                width: `${progress * 100}%`,
                backgroundColor: colors.primary,
              }}
            />
          </View>
          <View className="flex-row justify-between">
            <Text className="text-xs text-muted">
              {Math.floor(currentTrack.currentTime / 60)}:
              {String(currentTrack.currentTime % 60).padStart(2, "0")}
            </Text>
            <Text className="text-xs text-muted">
              {Math.floor(currentTrack.duration / 60)}:
              {String(currentTrack.duration % 60).padStart(2, "0")}
            </Text>
          </View>
        </View>

        {/* Playback Controls */}
        <View className="px-6 pb-8">
          {/* Primary Controls */}
          <View className="flex-row justify-around items-center mb-8">
            <TouchableOpacity
              onPress={() => setIsShuffle(!isShuffle)}
              style={{ opacity: isShuffle ? 1 : 0.5 }}
            >
              <IconSymbol name="shuffle" size={24} color={colors.primary} />
            </TouchableOpacity>

            <TouchableOpacity>
              <View
                className="w-16 h-16 rounded-full justify-center items-center"
                style={{ backgroundColor: colors.primary }}
              >
                <IconSymbol name="backward.fill" size={28} color="#FFFFFF" />
              </View>
            </TouchableOpacity>

            <TouchableOpacity
              onPress={() => setIsPlaying(!isPlaying)}
              className="justify-center items-center"
            >
              <View
                className="w-20 h-20 rounded-full justify-center items-center"
                style={{ backgroundColor: colors.primary }}
              >
                <IconSymbol
                  name={isPlaying ? "pause.fill" : "play.fill"}
                  size={32}
                  color="#FFFFFF"
                />
              </View>
            </TouchableOpacity>

            <TouchableOpacity>
              <View
                className="w-16 h-16 rounded-full justify-center items-center"
                style={{ backgroundColor: colors.primary }}
              >
                <IconSymbol name="forward.fill" size={28} color="#FFFFFF" />
              </View>
            </TouchableOpacity>

            <TouchableOpacity
              onPress={handleRepeatClick}
              style={{ opacity: repeatMode !== "off" ? 1 : 0.5 }}
            >
              <IconSymbol
                name={repeatMode === "one" ? "repeat.1" : "repeat"}
                size={24}
                color={colors.primary}
              />
            </TouchableOpacity>
          </View>

          {/* Secondary Controls */}
          <View className="flex-row justify-around">
            <TouchableOpacity className="items-center">
              <IconSymbol name="square.and.arrow.up" size={24} color={colors.muted} />
              <Text className="text-xs text-muted mt-2">Share</Text>
            </TouchableOpacity>

            <TouchableOpacity className="items-center">
              <IconSymbol name="list.bullet" size={24} color={colors.muted} />
              <Text className="text-xs text-muted mt-2">Queue</Text>
            </TouchableOpacity>

            <TouchableOpacity className="items-center">
              <IconSymbol name="slider.horizontal.3" size={24} color={colors.muted} />
              <Text className="text-xs text-muted mt-2">EQ</Text>
            </TouchableOpacity>

            <TouchableOpacity className="items-center">
              <IconSymbol name="ellipsis" size={24} color={colors.muted} />
              <Text className="text-xs text-muted mt-2">More</Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* Volume Control */}
        <View className="px-6 pb-8">
          <View className="flex-row items-center gap-3">
            <IconSymbol name="volume.mute.fill" size={20} color={colors.muted} />
            <View
              className="flex-1 h-1 rounded-full"
              style={{ backgroundColor: colors.border }}
            >
              <View
                className="h-1 rounded-full"
                style={{
                  width: "70%",
                  backgroundColor: colors.primary,
                }}
              />
            </View>
            <IconSymbol name="volume.2.fill" size={20} color={colors.muted} />
          </View>
        </View>

        {/* Spacer */}
        <View className="h-8" />
      </ScrollView>
    </ScreenContainer>
  );
}
