/** @type {const} */
const themeColors = {
  primary: { light: '#0A7EA4', dark: '#0A7EA4' },
  secondary: { light: '#FF6B35', dark: '#FF6B35' },
  background: { light: '#FFFFFF', dark: '#0F0F0F' },
  surface: { light: '#F5F5F5', dark: '#1A1A1A' },
  foreground: { light: '#1A1A1A', dark: '#FFFFFF' },
  muted: { light: '#666666', dark: '#AAAAAA' },
  border: { light: '#E5E7EB', dark: '#333333' },
  success: { light: '#22C55E', dark: '#4ADE80' },
  warning: { light: '#F59E0B', dark: '#FBBF24' },
  error: { light: '#EF4444', dark: '#F87171' },
};

module.exports = { themeColors };

// Export for theme.config.d.ts typings
module.exports.themeColorKeys = Object.keys(themeColors);
